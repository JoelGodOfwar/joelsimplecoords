package com.datacraftcoords;

public class Reference {
    public static final String PROXY_SERVER = "com.datacraftcoords.ServerProxy";
    public static final String PROXY_CLIENT = "com.datacraftcoords.ClientProxy";
   
}