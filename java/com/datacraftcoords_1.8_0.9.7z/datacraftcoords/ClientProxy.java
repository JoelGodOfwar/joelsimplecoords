package com.datacraftcoords;

import net.minecraft.client.settings.KeyBinding;

public class ClientProxy extends CommonProxy{
	public static KeyBinding[] KeyBindings;

}
